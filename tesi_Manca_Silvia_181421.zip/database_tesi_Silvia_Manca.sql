-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versione server:              10.1.10-MariaDB - mariadb.org binary distribution
-- S.O. server:                  Win32
-- HeidiSQL Versione:            9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dump della struttura del database software
CREATE DATABASE IF NOT EXISTS `software` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `software`;


-- Dump della struttura di tabella software.bassisti
CREATE TABLE IF NOT EXISTS `bassisti` (
  `stud_ID` int(11) NOT NULL,
  `stud_NOME` varchar(50) DEFAULT NULL,
  `stud_COGNOME` varchar(50) DEFAULT NULL,
  `stud_GENERE` bit(1) DEFAULT NULL,
  `stud_DATAN` date DEFAULT NULL,
  `stud_INDIRIZZO` varchar(50) DEFAULT NULL,
  `stud_CITTA` varchar(50) DEFAULT NULL,
  `stud_CAP` varchar(50) DEFAULT NULL,
  `stud_CELL1` varchar(50) DEFAULT NULL,
  `stud_PROPR1` varchar(50) DEFAULT NULL,
  `stud_CELL2` varchar(50) DEFAULT NULL,
  `stud_PROPR2` varchar(50) DEFAULT NULL,
  `stud_STRUMENTO` varchar(50) DEFAULT NULL,
  `stud_LIVELLO` int(11) DEFAULT NULL,
  PRIMARY KEY (`stud_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.bassisti: ~2 rows (circa)
DELETE FROM `bassisti`;
/*!40000 ALTER TABLE `bassisti` DISABLE KEYS */;
INSERT INTO `bassisti` (`stud_ID`, `stud_NOME`, `stud_COGNOME`, `stud_GENERE`, `stud_DATAN`, `stud_INDIRIZZO`, `stud_CITTA`, `stud_CAP`, `stud_CELL1`, `stud_PROPR1`, `stud_CELL2`, `stud_PROPR2`, `stud_STRUMENTO`, `stud_LIVELLO`) VALUES
	(1, 'Silvia', 'Manca', b'1', '1992-05-21', 'Via Salandra 5', 'Squinzano', '73018', '3271869395', 'Silvia', '3271869394', 'Mamma', 'basso', NULL),
	(16, 'Marco', 'Monti', b'0', '1998-12-02', 'via Lancia 9', 'Torino', '10121', '3378912345', 'mamma', '345879850', 'personale', 'Basso', NULL);
/*!40000 ALTER TABLE `bassisti` ENABLE KEYS */;


-- Dump della struttura di tabella software.batteristi
CREATE TABLE IF NOT EXISTS `batteristi` (
  `stud_ID` int(11) NOT NULL,
  `stud_NOME` varchar(50) DEFAULT NULL,
  `stud_COGNOME` varchar(50) DEFAULT NULL,
  `stud_GENERE` bit(1) DEFAULT NULL,
  `stud_DATAN` date DEFAULT NULL,
  `stud_INDIRIZZO` varchar(50) DEFAULT NULL,
  `stud_CITTA` varchar(50) DEFAULT NULL,
  `stud_CAP` varchar(50) DEFAULT NULL,
  `stud_CELL1` varchar(50) DEFAULT NULL,
  `stud_PROPR1` varchar(50) DEFAULT NULL,
  `stud_CELL2` varchar(50) DEFAULT NULL,
  `stud_PROPR2` varchar(50) DEFAULT NULL,
  `stud_STRUMENTO` varchar(50) DEFAULT NULL,
  `stud_LIVELLO` int(11) DEFAULT NULL,
  PRIMARY KEY (`stud_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.batteristi: ~5 rows (circa)
DELETE FROM `batteristi`;
/*!40000 ALTER TABLE `batteristi` DISABLE KEYS */;
INSERT INTO `batteristi` (`stud_ID`, `stud_NOME`, `stud_COGNOME`, `stud_GENERE`, `stud_DATAN`, `stud_INDIRIZZO`, `stud_CITTA`, `stud_CAP`, `stud_CELL1`, `stud_PROPR1`, `stud_CELL2`, `stud_PROPR2`, `stud_STRUMENTO`, `stud_LIVELLO`) VALUES
	(3, 'Marco', 'Monti', b'0', '1998-12-02', 'via Lancia 9', 'Torino', '10121', '3378912345', 'mamma', '337891234', '', 'Batteria', 2),
	(4, 'Gianni', 'Marra', b'0', '1995-06-08', 'Via Salandra, 7', 'Lecce', '73010', '34567890', 'suo', '3378912345', 'padre', 'Batteria', 3),
	(27, 'Giulio', 'Pierri', b'0', '2015-04-12', 'Via Monti,44', 'Squinzano', '73018', '3984569845', 'zia', '337891234', '', 'Batteria', 1),
	(51, 'Noemi', 'Basso', b'1', '1998-06-10', 'Via Roma', 'Torino', '10100', '347896587', 'personale', '347896587', 'mamma', 'Batteria', 2),
	(52, 'Luca', 'Rossi', b'0', '1992-04-10', 'Via Roma', 'Torino', '10121', '3271867876', 'madre', NULL, '', 'Batteria', 2);
/*!40000 ALTER TABLE `batteristi` ENABLE KEYS */;


-- Dump della struttura di tabella software.cantanti
CREATE TABLE IF NOT EXISTS `cantanti` (
  `stud_ID` int(11) NOT NULL,
  `stud_NOME` varchar(50) DEFAULT NULL,
  `stud_COGNOME` varchar(50) DEFAULT NULL,
  `stud_GENERE` bit(1) DEFAULT NULL,
  `stud_DATAN` date DEFAULT NULL,
  `stud_INDIRIZZO` varchar(50) DEFAULT NULL,
  `stud_CITTA` varchar(50) DEFAULT NULL,
  `stud_CAP` varchar(50) DEFAULT NULL,
  `stud_CELL1` varchar(50) DEFAULT NULL,
  `stud_PROPR1` varchar(50) DEFAULT NULL,
  `stud_CELL2` varchar(50) DEFAULT NULL,
  `stud_PROPR2` varchar(50) DEFAULT NULL,
  `stud_STRUMENTO` varchar(50) DEFAULT NULL,
  `stud_LIVELLO` int(11) DEFAULT NULL,
  PRIMARY KEY (`stud_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.cantanti: ~3 rows (circa)
DELETE FROM `cantanti`;
/*!40000 ALTER TABLE `cantanti` DISABLE KEYS */;
INSERT INTO `cantanti` (`stud_ID`, `stud_NOME`, `stud_COGNOME`, `stud_GENERE`, `stud_DATAN`, `stud_INDIRIZZO`, `stud_CITTA`, `stud_CAP`, `stud_CELL1`, `stud_PROPR1`, `stud_CELL2`, `stud_PROPR2`, `stud_STRUMENTO`, `stud_LIVELLO`) VALUES
	(5, 'Gianni', 'Marra', b'0', '1995-06-08', 'Via Salandra, 7', 'Lecce', '730100', '34567890', 'suo', '339874560', 'padre', 'Canto', 1),
	(19, 'Giorgio', 'Mastroleo', b'1', '1940-09-15', 'Corso Unione Sovietica', 'Milano', '10100', '339874560', '', '339874560', '', 'Canto', 1),
	(24, 'Antonella', 'Servales', b'0', '1913-12-13', 'Via Roma 15', 'Torino', '12255', '3256765435', 'Silvia', '339874560', '', 'Canto', 1);
/*!40000 ALTER TABLE `cantanti` ENABLE KEYS */;


-- Dump della struttura di tabella software.chitarristi
CREATE TABLE IF NOT EXISTS `chitarristi` (
  `stud_ID` int(11) DEFAULT NULL,
  `stud_NOME` varchar(50) DEFAULT NULL,
  `stud_COGNOME` varchar(50) DEFAULT NULL,
  `stud_GENERE` bit(1) DEFAULT NULL,
  `stud_DATAN` date DEFAULT NULL,
  `stud_INDIRIZZO` varchar(50) DEFAULT NULL,
  `stud_CITTA` varchar(50) DEFAULT NULL,
  `stud_CAP` varchar(50) DEFAULT NULL,
  `stud_CELL1` varchar(50) DEFAULT NULL,
  `stud_PROPR1` varchar(50) DEFAULT NULL,
  `stud_CELL2` varchar(50) DEFAULT NULL,
  `stud_PROPR2` varchar(50) DEFAULT NULL,
  `stud_STRUMENTO` varchar(50) DEFAULT NULL,
  `stud_LIVELLO` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.chitarristi: ~3 rows (circa)
DELETE FROM `chitarristi`;
/*!40000 ALTER TABLE `chitarristi` DISABLE KEYS */;
INSERT INTO `chitarristi` (`stud_ID`, `stud_NOME`, `stud_COGNOME`, `stud_GENERE`, `stud_DATAN`, `stud_INDIRIZZO`, `stud_CITTA`, `stud_CAP`, `stud_CELL1`, `stud_PROPR1`, `stud_CELL2`, `stud_PROPR2`, `stud_STRUMENTO`, `stud_LIVELLO`) VALUES
	(3, 'Gianni', 'Marra', b'0', '1995-06-08', 'Via Salandra, 7', 'Lecce', '730100', '34567890', 'suo', '34567890', 'padre', 'Chitarra', 1),
	(18, 'Giulia', 'Conoci', b'1', '1995-03-05', 'Via Milano 15', 'Torino', '10125', '34567890', 'personale', '34767890', 'madre', 'Chitarra', 1),
	(45, 'Mario', 'Miglietta', b'0', '1992-04-04', 'Via Copernico', 'Squinzano', '73018', '3271896985', 'suo', '34567890', 'padre', 'Chitarra', 1);
/*!40000 ALTER TABLE `chitarristi` ENABLE KEYS */;


-- Dump della struttura di tabella software.lezioni
CREATE TABLE IF NOT EXISTS `lezioni` (
  `lez_IDStud` int(11),
  `lez_NumLiv` int(11) NOT NULL,
  `lez_IDLiv` int(11),
  `lez_Data` date DEFAULT NULL,
  `lez_Orario` varchar(50) DEFAULT NULL,
  `lez_Commento` longtext,
  `lez_Valutazione` longtext,
  KEY `FK_lezioni_batteristi` (`lez_IDStud`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.lezioni: ~17 rows (circa)
DELETE FROM `lezioni`;
/*!40000 ALTER TABLE `lezioni` DISABLE KEYS */;
INSERT INTO `lezioni` (`lez_IDStud`, `lez_NumLiv`, `lez_IDLiv`, `lez_Data`, `lez_Orario`, `lez_Commento`, `lez_Valutazione`) VALUES
	(27, 1, 1, '2016-03-16', '15.30', 'commento della lezione', 'commento'),
	(28, 1, 1, '2016-03-15', '16.30', 'lezione', 'lezione'),
	(1, 1, 3, '2016-03-16', '13.30', 'commento', NULL),
	(3, 0, 2, '2016-03-15', '13.30', 'Monti', NULL),
	(3, 0, 2, '2016-03-16', '12.30', 'nota', NULL),
	(21, 2, 12, '2016-03-16', '12.45', 'spartiti', NULL),
	(47, 2, 12, '2016-03-09', '13:00', 'portare spartiti', NULL),
	(1, 1, 4, '2016-03-17', '08.30', 'spartiti', NULL),
	(1, 1, 3, '2016-03-18', '12.30', 'portare nuovo brano musicale', NULL),
	(50, 2, 1, '2016-03-17', '17.30', 'preparare canzone', NULL),
	(4, 3, 2, '2016-03-14', '15:50', 'provare meglio canzoni', NULL),
	(4, 3, 3, '2016-03-18', '17:30', 'stampare fotocopie', NULL),
	(27, 1, 0, '2016-03-16', '17:30', 'stampare fotocopie', NULL),
	(27, 1, 0, '2016-03-18', '08:30', 'stampare fotocopie', NULL),
	(3, 2, 11, '2016-03-16', '09:30', 'preparare brani nuovi', NULL),
	(52, 2, 1, '2016-03-16', '13.30', 'portare degli spartiti', NULL),
	(52, 2, 11, '2016-03-23', '13.30', 'portare degli spartiti', NULL);
/*!40000 ALTER TABLE `lezioni` ENABLE KEYS */;


-- Dump della struttura di tabella software.livello_1
CREATE TABLE IF NOT EXISTS `livello_1` (
  `liv_NUM` int(11) NOT NULL,
  `liv_ID` int(11) NOT NULL,
  `liv_ARGOMENTO` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='argomenti del livello';

-- Dump dei dati della tabella software.livello_1: ~26 rows (circa)
DELETE FROM `livello_1`;
/*!40000 ALTER TABLE `livello_1` DISABLE KEYS */;
INSERT INTO `livello_1` (`liv_NUM`, `liv_ID`, `liv_ARGOMENTO`) VALUES
	(1, 1, 'Postura e impostazione degli arti superiori ed inferiori sullo strumento '),
	(1, 2, 'Impostazione della presa  fulcro sulla bacchetta'),
	(1, 3, 'Stiks Control alternati e doppi'),
	(1, 4, 'Introduzione al metronomo e al ruolo ritmico del batterista'),
	(1, 5, 'Tempo Base 4/4'),
	(1, 6, 'Dislocato Semplice E Doppio'),
	(1, 7, '2/4'),
	(1, 8, 'Esercizio A Braccia Aperte Semplice E Complesso'),
	(1, 9, 'Contraccolpi'),
	(1, 10, 'Studio e presentazione del N.A.R.D. '),
	(1, 11, 'Scala dei rulli: QUARTI'),
	(1, 12, 'Scala dei rulli: OTTAVI'),
	(1, 13, 'Scala dei rulli: SEDICESIMI'),
	(1, 14, 'Scala dei rulli: TRENTADUESIMI'),
	(1, 15, 'Sviluppo fondamentale del senso del tempo attraverso rudimenti e ritmiche base '),
	(1, 16, 'Indipendenza e coordinazione degli arti'),
	(1, 17, 'Paradiddle Fondamento'),
	(1, 18, 'Paradiddle 1'),
	(1, 19, 'Paradiddle 4'),
	(1, 20, 'Standard rock rhythms in quarti'),
	(1, 21, 'Standard rock rhythms in ottavi'),
	(1, 22, 'Trasposizione ritmica '),
	(1, 23, 'Poliritmi'),
	(1, 24, 'Prime semplici improvvisazioni  ed esecuzione di brani semplici'),
	(1, 25, 'Ascolto guidato di brani , autori in base alle preferenze stilistiche dell’allievo '),
	(1, 26, 'MUSICOTERAPIA – Primi brani di approccio alla musica ambientale');
/*!40000 ALTER TABLE `livello_1` ENABLE KEYS */;


-- Dump della struttura di tabella software.livello_2
CREATE TABLE IF NOT EXISTS `livello_2` (
  `liv_NUM` int(11) NOT NULL,
  `liv_ID` int(11) NOT NULL,
  `liv_ARGOMENTO` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.livello_2: ~16 rows (circa)
DELETE FROM `livello_2`;
/*!40000 ALTER TABLE `livello_2` DISABLE KEYS */;
INSERT INTO `livello_2` (`liv_NUM`, `liv_ID`, `liv_ARGOMENTO`) VALUES
	(2, 1, 'Studio Di Figure Musicali Di Media Difficoltà Esecutiva '),
	(2, 2, 'Scala Dei Rulli: Quarti'),
	(2, 3, 'Scala Dei Rulli: Ottavi'),
	(2, 4, 'Scala Dei Rulli: Terzine'),
	(2, 5, 'Scala Dei Rulli: Sedicesimi'),
	(2, 6, 'Scala Dei Rulli: Sestine'),
	(2, 7, 'Scala Dei Rulli: Trentaduesimi'),
	(2, 8, 'Studio Di  Tutte Le Varianti Di Paradiddles '),
	(2, 9, 'Paradiddle 1'),
	(2, 10, 'Paradiddle 2'),
	(2, 11, 'Paradiddle 3'),
	(2, 12, 'Paradiddle 4'),
	(2, 13, 'Double Paradiddle'),
	(2, 14, 'Triple Paradiddle'),
	(2, 15, 'Studio Degli Accenti E Loro Posizionamento Sulle Principali Figure'),
	(2, 16, 'Studio dei 13 rudimenti del N.A.R.D. ( PATTERNS FONDAMENTALI )');
/*!40000 ALTER TABLE `livello_2` ENABLE KEYS */;


-- Dump della struttura di tabella software.livello_3
CREATE TABLE IF NOT EXISTS `livello_3` (
  `liv_NUM` int(11) NOT NULL,
  `liv_ID` int(11) NOT NULL,
  `liv_ARGOMENTO` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella software.livello_3: ~17 rows (circa)
DELETE FROM `livello_3`;
/*!40000 ALTER TABLE `livello_3` DISABLE KEYS */;
INSERT INTO `livello_3` (`liv_NUM`, `liv_ID`, `liv_ARGOMENTO`) VALUES
	(3, 1, 'Interazione tra diversi stili musicali in tempo reale'),
	(3, 2, 'Studio dei tempi dispari e il loro conteggio '),
	(3, 3, 'Sequenze di cinque colpi a mani alternate, a colpi doppi e tripli '),
	(3, 4, 'Colpi singoli alternati con spostamenti d’accento a quintine'),
	(3, 5, 'Paradiddles a quintine e relativi sviluppi sul set '),
	(3, 6, 'Letture con tempi composti'),
	(3, 7, 'Lettura ritmica solo rullante(3/8, 6/8, 9/8, 12/8) '),
	(3, 8, 'Ritmi composti dispari (3/8, 6/8, 9/8, 12/8) '),
	(3, 9, 'Interpretazioni di media difficoltà '),
	(3, 10, 'Approfondimento stili rock, blues, rap, hip hop, funky e fusion'),
	(3, 11, 'Accordatura della batteria e scelta timbrica in funzione dello stile'),
	(3, 12, 'Ideazione e sviluppo di un assolo '),
	(3, 13, 'Ensamble di batteria e percussioni '),
	(3, 14, 'Laboratori ritmici con musicisti (basso, chitarra, pianoforte e tastiere) '),
	(3, 15, 'Preparazione di brani musicali contemporanei finalizzata alla musica d’insieme (gruppi musicali e bands)'),
	(3, 16, 'Approfondimento delle tecniche batteristiche di Jonh Bonham, Ringo Starr, Gene Krupa e Billy Cobham'),
	(3, 17, 'MUSICOTERAPIA');
/*!40000 ALTER TABLE `livello_3` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
